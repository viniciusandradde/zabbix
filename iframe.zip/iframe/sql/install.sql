CREATE TABLE `glpi_plugin_iframe_iframes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comment` longtext COLLATE utf8_unicode_ci,
  `color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Formato hexadecimal',
  `date_creation` timestamp,
  `date_mod` timestamp,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `url` longtext COLLATE utf8_unicode_ci,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `show` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',  
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',    
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_iframe_iframes` (`id`, `name`, `comment`, `color`, `date_creation`, `date_mod`, `is_recursive`, `entities_id`, `url`, `active`, `show`, `is_deleted`, `users_id_recipient`, `users_id_lastupdater`) VALUES
(1, 'DashBoards', 'DashBoard Creado Usando Power BI', '#6bd813', '2023-01-01 05:59:59', '2023-01-01 15:31:38', 1, 0, 'https://app.powerbi.com/view?r=eyJrIjoiMzk1ZDc3OWUtNjdhNS00ODJiLThlMjEtMzQ4ZjMwOTNkMGUyIiwidCI6ImEzNjUwNGQ2LWEwNjEtNDBiYi04YmNkLWU2ZWVkOWQ4NWU5YSJ9', 1, 1, 0, 2, 2);

CREATE TABLE `glpi_plugin_iframe_iframes_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugin_iframe_iframes_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`plugin_iframe_iframes_id`,`groups_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


INSERT INTO `glpi_plugins` (`id`, `directory`, `name`, `version`, `state`, `author`, `homepage`, `license`) VALUES
(999, 'iframe', 'Inline Frame', '1.1.2', 1, '<a href=\"http://www.carm.es\">CARM</a>', 'http://www.carm.es', 'AGPL3');

INSERT INTO `glpi_profilerights` (`id`, `profiles_id`, `name`, `rights`) VALUES
(2212, 2, 'plugin_iframe', 0),
(2213, 3, 'plugin_iframe', 0),
(2215, 5, 'plugin_iframe', 0),
(2216, 6, 'plugin_iframe', 0),
(2217, 7, 'plugin_iframe', 0),
(2218, 8, 'plugin_iframe', 0),
(2219, 9, 'plugin_iframe', 0),
(2220, 10, 'plugin_iframe', 0),
(2221, 1, 'plugin_iframe', 0),
(2222, 4, 'plugin_iframe', 127),
(2243, 3, 'plugin_iframe_iframes_2', 1),
(2244, 10, 'plugin_iframe_iframes_2', 0),
(2245, 9, 'plugin_iframe_iframes_2', 0),
(2246, 5, 'plugin_iframe_iframes_2', 0),
(2247, 2, 'plugin_iframe_iframes_2', 0),
(2248, 8, 'plugin_iframe_iframes_2', 0),
(2249, 4, 'plugin_iframe_iframes_2', 1),
(2250, 7, 'plugin_iframe_iframes_2', 0),
(2251, 6, 'plugin_iframe_iframes_2', 1),
(2252, 1, 'plugin_iframe_iframes_2', 0),
(2283, 3, 'plugin_iframe_iframes_1', 1),
(2284, 10, 'plugin_iframe_iframes_1', 0),
(2285, 9, 'plugin_iframe_iframes_1', 1),
(2286, 5, 'plugin_iframe_iframes_1', 0),
(2287, 2, 'plugin_iframe_iframes_1', 0),
(2288, 8, 'plugin_iframe_iframes_1', 0),
(2289, 4, 'plugin_iframe_iframes_1', 1),
(2290, 7, 'plugin_iframe_iframes_1', 0),
(2291, 6, 'plugin_iframe_iframes_1', 0),
(2292, 1, 'plugin_iframe_iframes_1', 0);