# iframe
Plugin Iframe to GLPI 

The iframe plugin allows you to add a new tab called 'Governance View' to the Home page in which you can include PowerBi graphics using an Iframe.

You can create as many Iframes as you want, being able to configure the name of the tab and its color.

The display of each tab within the 'Vista Gobernanza' can be controlled directly by user profile or by group to which the user belongs.
