# Security Policy

## Reporting a Vulnerability

Please contact jdmarinz@inforges.es
